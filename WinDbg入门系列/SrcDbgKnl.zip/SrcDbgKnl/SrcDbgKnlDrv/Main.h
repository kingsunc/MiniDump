#ifndef __H__DRV_SRCDBGKNL__DRV__MAIN__
#define __H__DRV_SRCDBGKNL__DRV__MAIN__
//////////////////////////////////////////////////////////////////////////
#ifdef __cplusplus
extern "C" {
#endif

#include <ntddk.h>

NTSTATUS  DriverDispatch (IN PDEVICE_OBJECT DeviceObject, IN PIRP Irp);
NTSTATUS  DispatchRead (IN PDEVICE_OBJECT DeviceObject, IN PIRP Irp);
NTSTATUS DispatchIoCtrl(IN PDEVICE_OBJECT DeviceObject, IN PIRP Irp);
NTSTATUS  DriverEntry( IN PDRIVER_OBJECT DriverObject,  IN PUNICODE_STRING RegistryPath );
void DriverUnload(IN PDRIVER_OBJECT DriverObject);

#ifdef __cplusplus
}
#endif
//////////////////////////////////////////////////////////////////////////
#endif	//#ifndef __H__DRV_SRCDBGKNL__DRV__MAIN__